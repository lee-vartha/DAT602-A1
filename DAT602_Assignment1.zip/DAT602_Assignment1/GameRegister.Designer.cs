﻿namespace DAT602_Assignment1
{
    partial class GameRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameRegister));
            register_lbl = new Label();
            username_lbl = new Label();
            txt_username = new TextBox();
            email_lbl = new Label();
            txt_email = new TextBox();
            txt_password = new TextBox();
            password_lbl = new Label();
            button1 = new Button();
            btn_switch = new Button();
            pictureBox1 = new PictureBox();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // register_lbl
            // 
            register_lbl.AutoSize = true;
            register_lbl.BackColor = Color.Transparent;
            register_lbl.Font = new Font("SimSun", 18F);
            register_lbl.ForeColor = Color.Sienna;
            register_lbl.Location = new Point(120, 39);
            register_lbl.Name = "register_lbl";
            register_lbl.Size = new Size(133, 30);
            register_lbl.TabIndex = 11;
            register_lbl.Text = "Register";
            register_lbl.Click += label1_Click;
            // 
            // username_lbl
            // 
            username_lbl.AutoSize = true;
            username_lbl.BackColor = Color.Transparent;
            username_lbl.Font = new Font("SimSun", 10F);
            username_lbl.ForeColor = Color.Sienna;
            username_lbl.Location = new Point(43, 91);
            username_lbl.Name = "username_lbl";
            username_lbl.Size = new Size(80, 17);
            username_lbl.TabIndex = 13;
            username_lbl.Text = "Username";
            // 
            // txt_username
            // 
            txt_username.Font = new Font("SimSun", 11F);
            txt_username.ForeColor = Color.Sienna;
            txt_username.Location = new Point(43, 111);
            txt_username.Name = "txt_username";
            txt_username.Size = new Size(285, 28);
            txt_username.TabIndex = 12;
            txt_username.Text = "Enter Username...";
            // 
            // email_lbl
            // 
            email_lbl.AutoSize = true;
            email_lbl.BackColor = Color.Transparent;
            email_lbl.Font = new Font("SimSun", 10F);
            email_lbl.ForeColor = Color.Sienna;
            email_lbl.Location = new Point(43, 152);
            email_lbl.Name = "email_lbl";
            email_lbl.Size = new Size(53, 17);
            email_lbl.TabIndex = 15;
            email_lbl.Text = "Email";
            // 
            // txt_email
            // 
            txt_email.Font = new Font("SimSun", 11F);
            txt_email.ForeColor = Color.Sienna;
            txt_email.Location = new Point(43, 172);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(285, 28);
            txt_email.TabIndex = 14;
            txt_email.Text = "Enter Email...";
            // 
            // txt_password
            // 
            txt_password.Font = new Font("Segoe UI", 9F);
            txt_password.ForeColor = Color.Sienna;
            txt_password.Location = new Point(43, 238);
            txt_password.Name = "txt_password";
            txt_password.PasswordChar = '*';
            txt_password.Size = new Size(285, 27);
            txt_password.TabIndex = 17;
            // 
            // password_lbl
            // 
            password_lbl.AutoSize = true;
            password_lbl.BackColor = Color.Transparent;
            password_lbl.Font = new Font("SimSun", 10F);
            password_lbl.ForeColor = Color.Sienna;
            password_lbl.Location = new Point(42, 218);
            password_lbl.Name = "password_lbl";
            password_lbl.Size = new Size(80, 17);
            password_lbl.TabIndex = 16;
            password_lbl.Text = "Password";
            // 
            // button1
            // 
            button1.BackColor = Color.Wheat;
            button1.FlatAppearance.BorderColor = Color.SandyBrown;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("SimSun", 12F);
            button1.ForeColor = Color.Sienna;
            button1.Location = new Point(87, 294);
            button1.Name = "button1";
            button1.Size = new Size(189, 31);
            button1.TabIndex = 20;
            button1.Text = "Confirm";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // btn_switch
            // 
            btn_switch.BackColor = Color.Wheat;
            btn_switch.FlatAppearance.BorderColor = Color.SandyBrown;
            btn_switch.FlatStyle = FlatStyle.Flat;
            btn_switch.Font = new Font("SimSun", 8.25F);
            btn_switch.ForeColor = Color.Sienna;
            btn_switch.Location = new Point(41, 381);
            btn_switch.Name = "btn_switch";
            btn_switch.Size = new Size(285, 25);
            btn_switch.TabIndex = 21;
            btn_switch.Text = "Click to sign in to the game";
            btn_switch.UseVisualStyleBackColor = false;
            btn_switch.Click += btn_switch_Click_1;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(23, 318);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(48, 46);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Wheat;
            button2.FlatAppearance.BorderColor = Color.SandyBrown;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("SimSun", 7F);
            button2.ForeColor = Color.Sienna;
            button2.Location = new Point(12, 12);
            button2.Name = "button2";
            button2.Size = new Size(45, 27);
            button2.TabIndex = 23;
            button2.Text = "Back";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // GameRegister
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.InactiveCaption;
            BackgroundImage = Properties.Resources.Frame_1__3_;
            ClientSize = new Size(370, 421);
            Controls.Add(button2);
            Controls.Add(pictureBox1);
            Controls.Add(btn_switch);
            Controls.Add(button1);
            Controls.Add(txt_password);
            Controls.Add(password_lbl);
            Controls.Add(email_lbl);
            Controls.Add(txt_email);
            Controls.Add(username_lbl);
            Controls.Add(txt_username);
            Controls.Add(register_lbl);
            Name = "GameRegister";
            Text = "Register";
            Load += GameRegister_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label register_lbl;
        private Label username_lbl;
        private TextBox txt_username;
        private Label email_lbl;
        private TextBox txt_email;
        private TextBox txt_password;
        private Label password_lbl;
        private Button button1;
        private Button btn_switch;
        private PictureBox pictureBox1;
        private Button button2;
    }
}