using MySql.Data.MySqlClient;
using Org.BouncyCastle.Bcpg.OpenPgp;
using System.Windows.Forms;

namespace DAT602_Assignment1
{
    public partial class GameLogin : Form
    {
        private MySql.Data.MySqlClient.MySqlConnection MySqlConnection;

        public GameLogin()
        {
            InitializeComponent();
        }


        int attempts = 0;


        private void btn_confirm_Click(object sender, EventArgs e)
        {
            string username = txt_username.Text;
            string password = txt_password.Text;

            DataAccess dataAccess = new DataAccess();
            string loginResult = dataAccess.Login(username, password);

            if (loginResult == "Logged In")
            {
                GameLobby gameLobby = new GameLobby();
                gameLobby.Show();
                this.Hide();
            }
            else if (loginResult == "Locked Out")
            {
                GameLock gameLock = new GameLock();
                gameLock.Show();
                this.Hide();
            }
            else
            {
                attempts++;
                DisplayErrorMessages();
            }

        }

            private void DisplayErrorMessages()
            {
                lbl_error1.Visible = attempts == 1;
                lbl_error2.Visible = attempts == 2;
                lbl_error3.Visible = attempts == 3;
            }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_switch_Click(object sender, EventArgs e)
        {
            GameRegister gameRegister = new GameRegister();
            gameRegister.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GameStart gameStart = new GameStart();
            gameStart.Show();
            this.Hide();
        }
    }
}
