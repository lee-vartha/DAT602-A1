﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace DAT602_Assignment1
{
    class DataAccess
    {
        private static string connectionString
        {
            get { return "Server=localhost; Port=3306; Database=gamedb; Uid=root; password=pass;"; }

        }


        private static MySqlConnection _mySqlConnection = null;
        public static MySqlConnection mySqlConnection
        {
            get
            {
                if (_mySqlConnection == null)
                {
                    _mySqlConnection = new MySqlConnection(connectionString);
                }

                return _mySqlConnection;

            }
        }

        public string AddUserName(string pUserName)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var usernameParam = new MySqlParameter("@pUserName", MySqlDbType.VarChar, 50);
            usernameParam.Value = pUserName;
            parameters.Add(usernameParam);

            var dataSet = MySqlHelper.ExecuteDataset(DataAccess.mySqlConnection, "call AddUserName(@pUserName)", parameters.ToArray());

            // Expecting one table with one row
            return (dataSet.Tables[0].Rows[0])["MESSAGE"].ToString();
        }


        public List<Player> GetAllPlayers()
        {
            var players = new List<Player>();

            using (var connection = DataAccess.mySqlConnection)
            {
                connection.Open();
                using (var command = new MySqlCommand("GetAllPlayers", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            players.Add(new Player
                            {
                                UserName = reader["UserName"].ToString()
                            });
                        }
                    }
                }
            }

            return players;
        }

        public string TestConnection()
        {
            try
            {
                DataAccess.mySqlConnection.Open();
                return "Connection Successful";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                DataAccess.mySqlConnection.Close();
            }
        }

        public string Login(string pUserName, string pPassword)
        {
            List<MySqlParameter> parameters = new List<MySqlParameter>();
            var usernameParam = new MySqlParameter("@pUserName", MySqlDbType.VarChar, 50);
            usernameParam.Value = pUserName;
            parameters.Add(usernameParam);

            var passwordParam = new MySqlParameter("@pPassword", MySqlDbType.VarChar, 50);
            passwordParam.Value = pPassword;
            parameters.Add(passwordParam);

            var dataSet = MySqlHelper.ExecuteDataset(DataAccess.mySqlConnection, "call Login(@pUserName, @pPassword)", parameters.ToArray());

            // Expecting one table with one row
            return (dataSet.Tables[0].Rows[0])["MESSAGE"].ToString();



        }

    }
}