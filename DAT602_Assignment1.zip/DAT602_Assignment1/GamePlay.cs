﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{
    public partial class GamePlay : Form
    {
        public GamePlay()
        {
            InitializeComponent();
        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void GamePlay_Load(object sender, EventArgs e)
        {
            DataAccess dataAccess = new DataAccess();
            string result = dataAccess.TestConnection();
            MessageBox.Show(result);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GameLobby gameLobby = new GameLobby();
            gameLobby.Show();
            this.Hide();
        }
    }
}
