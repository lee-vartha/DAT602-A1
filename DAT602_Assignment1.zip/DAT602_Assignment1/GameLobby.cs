﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{
    public partial class GameLobby : Form
    {
        public GameLobby()
        {
            InitializeComponent();
            // Example list of online players
            var onlinePlayers = new List<string>
            {
                "UserName123",
                "UserName246"
            };

            LoadOnlinePlayers(onlinePlayers);

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            GameStart gameStart = new GameStart();
            gameStart.Show();
            this.Hide();
        }

        public class PlayerEntryControl : UserControl
        {
            private Label playerNameLabel;

            public PlayerEntryControl(string playerName)
            {
                // Initialize and set up labels and any other controls

                playerNameLabel = new Label
                {
                    Text = playerName,
                    Size = new Size(800, 30), // Set size slightly smaller to fit within the control
                    BorderStyle = BorderStyle.FixedSingle,
                    FlatStyle = FlatStyle.Flat,
                    ForeColor = Color.Sienna,
                    BackColor = Color.Wheat,

                };


                // Layout setup
                this.Controls.Add(playerNameLabel);

            }
        }




        // In your form load or appropriate event
        private void LoadOnlinePlayers(List<string> onlinePlayers)
        {
            flowpnl_online.Controls.Clear();

            foreach (var player in onlinePlayers)
            {
                var playerEntry = new PlayerEntryControl(player);
                flowpnl_online.Controls.Add(playerEntry);
            }

            flowpnl_online.Visible = onlinePlayers.Any(); // Show only if there are online players
        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void loggedIn_lbl_Click(object sender, EventArgs e)
        {

        }

        private void newGame_btn_Click(object sender, EventArgs e)
        {
            GamePlay gamePlay = new GamePlay();
            gamePlay.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void GameLobby_Load(object sender, EventArgs e)
        {

        }

        private void adminWin_btn_Click(object sender, EventArgs e)
        {
            GameAdmin gameAdmin = new GameAdmin();
            gameAdmin.Show();
            this.Hide();

        }

        private void flowpnl_online_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}