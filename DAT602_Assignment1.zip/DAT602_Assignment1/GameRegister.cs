﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAT602_Assignment1
{

    public partial class GameRegister : Form
    {

        private MySql.Data.MySqlClient.MySqlConnection MySqlConnection;


        public GameRegister()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GameRegister_Load(object sender, EventArgs e)
        {

        }

        private void btn_switch_Click(object sender, EventArgs e)
        {

        }

        private void btn_switch_Click_1(object sender, EventArgs e)
        {
            GameLogin gameLogin = new GameLogin();
            gameLogin.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataAccess gameDB = new DataAccess();
            MessageBox.Show(gameDB.AddUserName(txt_username.Text));

            GameLobby gameLobby = new GameLobby();
            gameLobby.Show();
            this.Hide();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GameStart gameStart = new GameStart();
            gameStart.Show();
            this.Hide();
        }
    }
}
