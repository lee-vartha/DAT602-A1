﻿namespace DAT602_Assignment1
{
    partial class GameAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            flowpnl_live = new FlowLayoutPanel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            newGame_btn = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label4 = new Label();
            flowpnl_registered = new FlowLayoutPanel();
            flowpnl_live.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("SimSun", 11F);
            label1.ForeColor = Color.Sienna;
            label1.Location = new Point(189, 83);
            label1.Name = "label1";
            label1.Size = new Size(129, 19);
            label1.TabIndex = 4;
            label1.Text = "Admin Window";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("SimSun", 15F);
            label2.ForeColor = Color.Sienna;
            label2.Location = new Point(146, 48);
            label2.Name = "label2";
            label2.Size = new Size(220, 25);
            label2.TabIndex = 3;
            label2.Text = "Bees and Blossom";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("SimSun", 9F);
            label3.ForeColor = Color.Sienna;
            label3.Location = new Point(22, 100);
            label3.Name = "label3";
            label3.Size = new Size(95, 15);
            label3.TabIndex = 30;
            label3.Text = "Live Games:";
            // 
            // flowpnl_live
            // 
            flowpnl_live.Controls.Add(flowLayoutPanel1);
            flowpnl_live.Location = new Point(19, 118);
            flowpnl_live.Name = "flowpnl_live";
            flowpnl_live.Size = new Size(250, 230);
            flowpnl_live.TabIndex = 29;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel1.Location = new Point(3, 3);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(250, 125);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // newGame_btn
            // 
            newGame_btn.BackColor = Color.Wheat;
            newGame_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            newGame_btn.FlatStyle = FlatStyle.Flat;
            newGame_btn.Font = new Font("SimSun", 10F);
            newGame_btn.ForeColor = Color.Sienna;
            newGame_btn.Location = new Point(291, 121);
            newGame_btn.Name = "newGame_btn";
            newGame_btn.Size = new Size(210, 41);
            newGame_btn.TabIndex = 31;
            newGame_btn.Text = "Kill Selected Game";
            newGame_btn.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Wheat;
            button1.FlatAppearance.BorderColor = Color.SandyBrown;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("SimSun", 10F);
            button1.ForeColor = Color.Sienna;
            button1.Location = new Point(291, 307);
            button1.Name = "button1";
            button1.Size = new Size(210, 41);
            button1.TabIndex = 32;
            button1.Text = "Delete Selected User";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Wheat;
            button2.FlatAppearance.BorderColor = Color.SandyBrown;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("SimSun", 10F);
            button2.ForeColor = Color.Sienna;
            button2.Location = new Point(291, 260);
            button2.Name = "button2";
            button2.Size = new Size(210, 41);
            button2.TabIndex = 33;
            button2.Text = "Edit Selected User";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Wheat;
            button3.FlatAppearance.BorderColor = Color.SandyBrown;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("SimSun", 10F);
            button3.ForeColor = Color.Sienna;
            button3.Location = new Point(291, 213);
            button3.Name = "button3";
            button3.Size = new Size(210, 41);
            button3.TabIndex = 34;
            button3.Text = "Create New User";
            button3.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("SimSun", 9F);
            label4.ForeColor = Color.Sienna;
            label4.Location = new Point(22, 374);
            label4.Name = "label4";
            label4.Size = new Size(159, 15);
            label4.TabIndex = 36;
            label4.Text = "Registered Players:";
            // 
            // flowpnl_registered
            // 
            flowpnl_registered.AutoSize = true;
            flowpnl_registered.Location = new Point(19, 392);
            flowpnl_registered.Name = "flowpnl_registered";
            flowpnl_registered.Size = new Size(476, 165);
            flowpnl_registered.TabIndex = 35;
            flowpnl_registered.Paint += flowpnl_registered_Paint;
            // 
            // GameAdmin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Frame_1__3_;
            ClientSize = new Size(513, 589);
            Controls.Add(label4);
            Controls.Add(flowpnl_registered);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(newGame_btn);
            Controls.Add(label3);
            Controls.Add(flowpnl_live);
            Controls.Add(label1);
            Controls.Add(label2);
            Name = "GameAdmin";
            Text = "GameAdmin";
            Load += GameAdmin_Load;
            flowpnl_live.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private FlowLayoutPanel flowpnl_live;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button newGame_btn;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label4;
        private FlowLayoutPanel flowpnl_registered;
    }
}