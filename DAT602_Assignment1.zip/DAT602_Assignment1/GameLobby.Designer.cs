﻿namespace DAT602_Assignment1
{
    partial class GameLobby
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            label1 = new Label();
            flowpnl_live = new FlowLayoutPanel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            flowpnl_online = new FlowLayoutPanel();
            newGame_btn = new Button();
            adminWin_btn = new Button();
            logout_btn = new Button();
            deleteAcc_btn = new Button();
            loggedIn_lbl = new Label();
            back_btn = new Button();
            label3 = new Label();
            label4 = new Label();
            flowpnl_live.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("SimSun", 15F);
            label2.ForeColor = Color.Sienna;
            label2.Location = new Point(147, 42);
            label2.Name = "label2";
            label2.Size = new Size(220, 25);
            label2.TabIndex = 1;
            label2.Text = "Bees and Blossom";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("SimSun", 11F);
            label1.ForeColor = Color.Sienna;
            label1.Location = new Point(198, 77);
            label1.Name = "label1";
            label1.Size = new Size(109, 19);
            label1.TabIndex = 2;
            label1.Text = "Game Lobby";
            // 
            // flowpnl_live
            // 
            flowpnl_live.Controls.Add(flowLayoutPanel1);
            flowpnl_live.Location = new Point(18, 117);
            flowpnl_live.Name = "flowpnl_live";
            flowpnl_live.Size = new Size(250, 230);
            flowpnl_live.TabIndex = 3;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel1.Location = new Point(3, 3);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(250, 125);
            flowLayoutPanel1.TabIndex = 0;
            flowLayoutPanel1.Paint += flowLayoutPanel1_Paint;
            // 
            // flowpnl_online
            // 
            flowpnl_online.FlowDirection = FlowDirection.TopDown;
            flowpnl_online.Location = new Point(18, 387);
            flowpnl_online.Margin = new Padding(3, 0, 3, 3);
            flowpnl_online.Name = "flowpnl_online";
            flowpnl_online.Size = new Size(476, 165);
            flowpnl_online.TabIndex = 4;
            flowpnl_online.Paint += flowpnl_online_Paint;
            // 
            // newGame_btn
            // 
            newGame_btn.BackColor = Color.Wheat;
            newGame_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            newGame_btn.FlatStyle = FlatStyle.Flat;
            newGame_btn.Font = new Font("SimSun", 12F);
            newGame_btn.ForeColor = Color.Sienna;
            newGame_btn.Location = new Point(284, 117);
            newGame_btn.Name = "newGame_btn";
            newGame_btn.Size = new Size(210, 41);
            newGame_btn.TabIndex = 21;
            newGame_btn.Text = "New 1v1 Game";
            newGame_btn.UseVisualStyleBackColor = false;
            newGame_btn.Click += newGame_btn_Click;
            // 
            // adminWin_btn
            // 
            adminWin_btn.AutoEllipsis = true;
            adminWin_btn.BackColor = Color.Wheat;
            adminWin_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            adminWin_btn.FlatStyle = FlatStyle.Flat;
            adminWin_btn.Font = new Font("SimSun", 12F);
            adminWin_btn.ForeColor = Color.Sienna;
            adminWin_btn.Location = new Point(284, 164);
            adminWin_btn.Name = "adminWin_btn";
            adminWin_btn.Size = new Size(210, 41);
            adminWin_btn.TabIndex = 22;
            adminWin_btn.Text = "Admin Window";
            adminWin_btn.UseVisualStyleBackColor = false;
            adminWin_btn.Click += adminWin_btn_Click;
            // 
            // logout_btn
            // 
            logout_btn.BackColor = Color.Wheat;
            logout_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            logout_btn.FlatStyle = FlatStyle.Flat;
            logout_btn.Font = new Font("SimSun", 10F);
            logout_btn.ForeColor = Color.Sienna;
            logout_btn.Location = new Point(284, 267);
            logout_btn.Name = "logout_btn";
            logout_btn.Size = new Size(105, 41);
            logout_btn.TabIndex = 24;
            logout_btn.Text = "Log Out";
            logout_btn.UseVisualStyleBackColor = false;
            // 
            // deleteAcc_btn
            // 
            deleteAcc_btn.BackColor = Color.Wheat;
            deleteAcc_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            deleteAcc_btn.FlatStyle = FlatStyle.Flat;
            deleteAcc_btn.Font = new Font("SimSun", 8F);
            deleteAcc_btn.ForeColor = Color.Sienna;
            deleteAcc_btn.Location = new Point(395, 267);
            deleteAcc_btn.Name = "deleteAcc_btn";
            deleteAcc_btn.Size = new Size(99, 41);
            deleteAcc_btn.TabIndex = 25;
            deleteAcc_btn.Text = "Delete Account";
            deleteAcc_btn.UseVisualStyleBackColor = false;
            // 
            // loggedIn_lbl
            // 
            loggedIn_lbl.AutoSize = true;
            loggedIn_lbl.BackColor = Color.Transparent;
            loggedIn_lbl.Font = new Font("SimSun", 9F);
            loggedIn_lbl.ForeColor = Color.Sienna;
            loggedIn_lbl.Location = new Point(284, 242);
            loggedIn_lbl.Name = "loggedIn_lbl";
            loggedIn_lbl.Size = new Size(87, 15);
            loggedIn_lbl.TabIndex = 26;
            loggedIn_lbl.Text = "Logged in:";
            loggedIn_lbl.Click += loggedIn_lbl_Click;
            // 
            // back_btn
            // 
            back_btn.BackColor = Color.Wheat;
            back_btn.FlatAppearance.BorderColor = Color.SandyBrown;
            back_btn.FlatStyle = FlatStyle.Flat;
            back_btn.Font = new Font("SimSun", 12F);
            back_btn.ForeColor = Color.Sienna;
            back_btn.Location = new Point(284, 314);
            back_btn.Name = "back_btn";
            back_btn.Size = new Size(210, 33);
            back_btn.TabIndex = 27;
            back_btn.Text = "Back to Start";
            back_btn.UseVisualStyleBackColor = false;
            back_btn.Click += back_btn_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("SimSun", 9F);
            label3.ForeColor = Color.Sienna;
            label3.Location = new Point(21, 99);
            label3.Name = "label3";
            label3.Size = new Size(95, 15);
            label3.TabIndex = 28;
            label3.Text = "Live Games:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("SimSun", 9F);
            label4.ForeColor = Color.Sienna;
            label4.Location = new Point(21, 369);
            label4.Name = "label4";
            label4.Size = new Size(127, 15);
            label4.TabIndex = 29;
            label4.Text = "Online Players:";
            label4.Click += label4_Click;
            // 
            // GameLobby
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Frame_1__3_;
            ClientSize = new Size(513, 589);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(back_btn);
            Controls.Add(loggedIn_lbl);
            Controls.Add(deleteAcc_btn);
            Controls.Add(logout_btn);
            Controls.Add(adminWin_btn);
            Controls.Add(newGame_btn);
            Controls.Add(flowpnl_online);
            Controls.Add(flowpnl_live);
            Controls.Add(label1);
            Controls.Add(label2);
            Name = "GameLobby";
            Text = "GameLobby";
            Load += GameLobby_Load;
            flowpnl_live.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Label label1;
        private FlowLayoutPanel flowpnl_live;
        private FlowLayoutPanel flowpnl_online;
        private Button newGame_btn;
        private Button adminWin_btn;
        private Button logout_btn;
        private Button deleteAcc_btn;
        private Label loggedIn_lbl;
        private Button back_btn;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label label3;
        private Label label4;
    }
}