﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static DAT602_Assignment1.GameLobby;

namespace DAT602_Assignment1
{
    public partial class GameAdmin : Form
    {
        public GameAdmin()
        {
            InitializeComponent();

            var registedPlayers = new List<string>
            {
                // based on what is listed in the database (of registered players) - no test data
                "UserName123",
                "UserName246",
                "UserName369",
            };

            LoadRegisteredPlayers(registedPlayers);
        }

        private void GameAdmin_Load(object sender, EventArgs e)
        {
            DataAccess dataAccess = new DataAccess();
            string result = dataAccess.TestConnection();
            MessageBox.Show(result);

        }

        private void flowpnl_registered_Paint(object sender, PaintEventArgs e)
        {

        }


        public class PlayerEntryControl : UserControl
        {
            private Label playerNameLabel;

            public PlayerEntryControl(string playerName)
            {
                playerNameLabel = new Label
                {
                    Text = playerName,
                    AutoSize = false, // Disable AutoSize to control the size manually
                    Size = new Size(464, 41), // Set size slightly smaller to fit within the control
                    BorderStyle = BorderStyle.FixedSingle,
                    FlatStyle = FlatStyle.Flat,
                    ForeColor = Color.Sienna,
                    BackColor = Color.Wheat,

                };

                this.Controls.Add(playerNameLabel);

            }
        }


        private void LoadRegisteredPlayers(List<string> registeredPlayers)
        {
            flowpnl_registered.Controls.Clear();

            foreach (var player in registeredPlayers)
            {
                var playerEntry = new PlayerEntryControl(player);
                flowpnl_registered.Controls.Add(playerEntry);
            }

            flowpnl_registered.Visible = registeredPlayers.Any(); // Show only if there are registered players
        }

     
    }
}
